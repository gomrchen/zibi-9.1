<?php

add_action('widgets_init', 'widget_register_slider');
function widget_register_slider()
{
    register_widget('widget_ui_slider');
}

class widget_ui_slider extends WP_Widget
{
    public function __construct()
    {
        $widget = array(
            'w_id'        => 'widget_ui_slider',
            'w_name'      => _name(__('幻灯片(老版即将删除)', 'zib_language')),
            'classname'   => '',
            'description' => __('老版幻灯片模块（！即将删除）', 'zib_language'),
        );
        parent::__construct($widget['w_id'], $widget['w_name'], $widget);
    }

    public function form($instance)
    {
        $defaults = array(
            'in_affix'    => '',
            'class'       => 'slide-widget',
            'loop'        => 'on',
            'type'        => '',
            'effect'      => 'slide',
            'blank'       => '',
            'button'      => 'on',
            'pagination'  => 'on',
            'interval'    => 4,
            'null'        => '',
            'auto_height' => '',
            'pc_height'   => 400,
            'm_height'    => 180,
            'img_ids'     => array(),
        );

        $defaults['img_ids'][] = array(
            'title' => '',
            'dec'   => '',
            'href'  => '',
            'link'  => '',
        );

        $defaults['img_ids'][] = array(
            'title' => '',
            'dec'   => '',
            'href'  => '',
            'link'  => '',
        );

        $instance = wp_parse_args((array) $instance, $defaults);

        $img_html = '';
        $img_i    = 0;

        foreach ($instance['img_ids'] as $category) {
            $_html_a = '<label>' . sprintf(__('幻灯片%d-标题', 'zib_language'), $img_i + 1) . '<input style="width:100%;" type="text" id="' . $this->get_field_id('img_ids') . '[' . $img_i . '].title" name="' . $this->get_field_name('img_ids') . '[' . $img_i . '][title]" value="' . $instance['img_ids'][$img_i]['title'] . '" /></label>';
            $_html_b = '<label>' . sprintf(__('幻灯片%d-简介', 'zib_language'), $img_i + 1) . '<input style="width:100%;" type="text" id="' . $this->get_field_id('img_ids') . '[' . $img_i . '].dec" name="' . $this->get_field_name('img_ids') . '[' . $img_i . '][dec]" value="' . $instance['img_ids'][$img_i]['dec'] . '" /></label>';
            $_html_b .= '<label>' . sprintf(__('幻灯片%d-链接', 'zib_language'), $img_i + 1) . '<input style="width:100%;" type="text" id="' . $this->get_field_id('img_ids') . '[' . $img_i . '].href" name="' . $this->get_field_name('img_ids') . '[' . $img_i . '][href]" value="' . $instance['img_ids'][$img_i]['href'] . '" /></label>';

            $_html_c = '<label>' . sprintf(__('幻灯片%d-图片', 'zib_language'), $img_i + 1) . '<input style="width:100%;" type="text" id="' . $this->get_field_id('img_ids') . '[' . $img_i . '].link" name="' . $this->get_field_name('img_ids') . '[' . $img_i . '][link]" value="' . $instance['img_ids'][$img_i]['link'] . '" /></label>';

            $_html_d = '<div class="">' . $_html_c . '<button type="button" class="button ashu_upload_button">' . __('选择图片', 'zib_language') . '</button><button type="button" class="button delimg_upload_button">' . __('移除图片', 'zib_language') . '</button><div class="widget_ui_slider_box"><img src="' . $instance['img_ids'][$img_i]['link'] . '"></div></div>';

            $_tt  = '<div class="panel"><h4 class="panel-title">' . sprintf(__('幻灯片%d：', 'zib_language'), $img_i + 1) . $instance['img_ids'][$img_i]['title'] . '</h4><div class="panel-hide panel-conter">';
            $_tt2 = '</div></div>';

            $img_html .= '<div class="widget_ui_slider_g">' . $_tt . $_html_a . $_html_b . $_html_d . $_tt2 . '</div>';
            $img_i++;
        }

        $add_b = '<button type="button" data-name="' . $this->get_field_name('img_ids') . '" data-count="' . $img_i . '" class="button add_button add_slider_button">' . __('添加幻灯片', 'zib_language') . '</button>';
        $add_b .= '<button type="button" data-name="' . $this->get_field_name('img_ids') . '" data-count="' . $img_i . '" class="button rem_lists_button">' . __('删除幻灯片', 'zib_language') . '</button>';
        $img_html .= $add_b;
        //echo '<pre>' . json_encode($instance) . '</pre>';
        echo '<p style=" color: #f03131; ">' . __('此模块为旧版，下次更新会删除此模块，不再推荐使用！请使用更强大的：zibll幻灯片(新)替代此功能', 'zib_language') . '</p>';

?>
        <p>
            <label>
                <?php _e('播放速度（每张停留时间多少秒）：', 'zib_language'); ?>
                <input style="width:100%;" id="<?php echo $this->get_field_id('interval');
                                                ?>" name="<?php echo $this->get_field_name('interval');
                    ?>" type="number" value="<?php echo $instance['interval'];
                                    ?>" size="24" />
            </label>
        </p>
        <p>
            <label>
                <input style="vertical-align:-3px;margin-right:4px;" class="checkbox" type="checkbox" <?php checked($instance['in_affix'], 'on'); ?> id="<?php echo $this->get_field_id('in_affix'); ?>" name="<?php echo $this->get_field_name('in_affix'); ?>"> <?php _e('侧栏随动（仅在侧边栏有效）', 'zib_language'); ?>
            </label>
        </p>
        <p>
            <label>
                <input style="vertical-align:-3px;margin-right:4px;" class="checkbox" type="checkbox" <?php checked($instance['loop'], 'on'); ?> id="<?php echo $this->get_field_id('loop'); ?>" name="<?php echo $this->get_field_name('loop'); ?>"> <?php _e('循环播放', 'zib_language'); ?>
            </label>
        </p>
        <p>
            <label>
                <input style="vertical-align:-3px;margin-right:4px;" class="checkbox" type="checkbox" <?php checked($instance['button'], 'on'); ?> id="<?php echo $this->get_field_id('button'); ?>" name="<?php echo $this->get_field_name('button'); ?>"> <?php _e('显示翻页按钮', 'zib_language'); ?>
            </label>
        </p>
        <p>
            <label>
                <input style="vertical-align:-3px;margin-right:4px;" class="checkbox" type="checkbox" <?php checked($instance['pagination'], 'on'); ?> id="<?php echo $this->get_field_id('pagination'); ?>" name="<?php echo $this->get_field_name('pagination'); ?>"> <?php _e('显示指示器', 'zib_language'); ?>
            </label>
        </p>
        <p>
            <label>
                <input style="vertical-align:-3px;margin-right:4px;" class="checkbox" type="checkbox" <?php checked($instance['blank'], 'on'); ?> id="<?php echo $this->get_field_id('blank'); ?>" name="<?php echo $this->get_field_name('blank'); ?>"> <?php _e('链接新窗口打开', 'zib_language'); ?>
            </label>
        </p>
        <p>
            <label>
                <input style="vertical-align:-3px;margin-right:4px;" class="checkbox" type="checkbox" <?php checked($instance['auto_height'], 'on'); ?> id="<?php echo $this->get_field_id('auto_height'); ?>" name="<?php echo $this->get_field_name('auto_height'); ?>"> <?php _e('自动高度', 'zib_language'); ?>
            </label>
        <div>
            <label>
                <i style="width:100%;color:#f60;"><?php _e('如果勾选了自动高度，下方的固定高度则不生效', 'zib_language'); ?></i>
            </label>
        </div>

        </p>
        <p>
            <label>
                <?php _e('（固定高度）电脑端高度：', 'zib_language'); ?>
                <input style="width:100%;" id="<?php echo $this->get_field_id('pc_height');
                                                ?>" name="<?php echo $this->get_field_name('pc_height');
                    ?>" type="number" value="<?php echo $instance['pc_height'];
                                    ?>" size="24" />
            </label>
        </p>
        <p>
            <label>
                <?php _e('（固定高度）手机端高度：', 'zib_language'); ?>
                <input style="width:100%;" id="<?php echo $this->get_field_id('m_height');
                                                ?>" name="<?php echo $this->get_field_name('m_height');
                    ?>" type="number" value="<?php echo $instance['m_height'];
                                    ?>" size="24" />
            </label>
        </p>

        <p>
            <label>
                <?php _e('切换动画：', 'zib_language'); ?>
                <select style="width:100%;" id="<?php echo $this->get_field_id('effect');
                                                ?>" name="<?php echo $this->get_field_name('effect');
                    ?>">
                    <option value="slide" <?php selected('slide', $instance['effect']);
                                            ?>><?php _e('滑动', 'zib_language'); ?></option>
                    <option value="fade" <?php selected('fade', $instance['effect']);
                                            ?>><?php _e('淡出淡入', 'zib_language'); ?></option>
                    <option value="cube" <?php selected('cube', $instance['effect']);
                                            ?>><?php _e('3D方块', 'zib_language'); ?></option>
                    <option value="coverflow" <?php selected('coverflow', $instance['effect']);
                                                ?>><?php _e('3D滑入', 'zib_language'); ?></option>
                    <option value="flip" <?php selected('flip', $instance['effect']);
                                            ?>><?php _e('3D翻转', 'zib_language'); ?></option>
                </select>
            </label>
        </p>
        <div class="widget_ui_slider_lists">
            <?php echo $img_html; ?>
            <label>
                <input style="vertical-align:-3px;margin-right:4px;" class="checkbox hide" type="checkbox" <?php checked($instance['null'], 'on'); ?> id="<?php echo $this->get_field_id('null'); ?>" name="<?php echo $this->get_field_name('null'); ?>"><a class="button ok_button"><?php _e('应用', 'zib_language'); ?></a>
            </label>

        </div>
        <p>
            <label>
                <i style="width:100%;color:#f60;"><?php _e('由于WordPress小工具逻辑，会导致后插入的幻灯片偶尔无法保存，请多试几次即可', 'zib_language'); ?></i>
            </label>
        </p>

        <?php wp_enqueue_media(); ?>
    <?php
    }

    public function widget($args, $instance)
    {

        extract($args);

        $defaults = array(
            'class'     => 'slide-widget',
            'in_affix'  => '',
            'type'      => '',
            'effect'    => 'slide',
            'interval'  => 4,
            'null'      => '',
            'pc_height' => 400,
            'm_height'  => 180,
            'img_ids'   => array(),
        );

        $defaults['img_ids'][] = array(
            'title' => '',
            'dec'   => '',
            'href'  => '',
            'link'  => '',
        );

        $defaults['img_ids'][] = array(
            'title' => '',
            'dec'   => '',
            'href'  => '',
            'link'  => '',
        );

        $instance = wp_parse_args((array) $instance, $defaults);

        $sliders = array(
            'class'       => 'slide-widget',
            'loop'        => !empty($instance['loop']) ? true : false,
            'type'        => '',
            'button'      => !empty($instance['button']) ? true : false,
            'pagination'  => !empty($instance['pagination']) ? true : false,
            'pc_height'   => $instance['pc_height'],
            'm_height'    => $instance['m_height'],
            'effect'      => $instance['effect'],
            'auto_height' => !empty($instance['auto_height']) ? true : false,
            'interval'    => (int) $instance['interval'] * 1000,
        );

        foreach ($instance['img_ids'] as $slide_img) {
            $desc = '<p class="em14">' . $slide_img['title'] . '</p>' . $slide_img['dec'];
            if ($slide_img['link']) {
                $slide = array(
                    'href'  => $slide_img['href'],
                    'image' => $slide_img['link'],
                    'blank' => !empty($instance['blank']) ? true : false,
                    'desc'  => $desc,
                );
                $sliders['slides'][] = $slide;
            }
        }
        $in_affix = $instance['in_affix'] ? ' data-affix="true"' : '';
        echo $in_affix ? '<div' . $in_affix . '>' : '';

        // echo '<pre>'.json_encode($instance).'</pre>';
        zib_get_img_slider($sliders);
        echo $in_affix ? '</div>' : '';

    ?>

<?php
    }
}

function zib_widget_ui_slider($args, $instance)
{
    if (empty($instance['slides'])) {
        if (is_super_admin()) {
            echo '<div class="c-red muted-box mb20"><b>' . sprintf(__('[%s]幻灯片模块：', 'zib_language'), __('幻灯片(新)', 'zib_language')) . '</b>' . __('当前配置下没有可显示的内容，请正确配置或移出该模块', 'zib_language') . '</div>';
        }
        return;
    }

    $header_slider        = $instance['slides'];
    $header_slider_option = $instance['option'];

    //判断配置是否为空
    if (!is_array($header_slider) || !is_array($header_slider_option) || empty($header_slider[0])) {
        return;
    }

    $header_slider_option['class']  = 'slide-widget mb20';
    $header_slider_option['slides'] = $header_slider;

    zib_new_slider($header_slider_option);
}
add_action('after_setup_theme', 'zib_widget_register_cfs_slider');

function zib_widget_register_cfs_slider()
{
    $imagepath = get_template_directory_uri() . '/img/';

    Zib_CFSwidget::create('zib_widget_ui_slider', array(
        'title'       => __('幻灯片(新)', 'zib_language'),
        'zib_affix'   => true,
        'zib_show'    => true,
        'description' => __('多张图片轮训播放的幻灯片模块，支持视频、图片、文字等内容的展示', 'zib_language'),
        'fields'      => array(
            array(
                'id'                     => 'slides',
                'type'                   => 'group',
                'min'                    => '1',
                'accordion_title_number' => true,
                'accordion_title_auto'   => false,
                'accordion_title_prefix' => __('幻灯片', 'zib_language'),
                'button_title'           => __('添加幻灯片', 'zib_language'),
                'title'                  => __('幻灯片内容', 'zib_language'),
                'subtitle'               => __('添加幻灯片', 'zib_language'),
                'desc'                   => __('注意：当添加的幻灯片内容只有一个的时候，则不会以幻灯片的形式展示（不能滑动切换，相当于单个图片或视频）', 'zib_language') . '<div class="c-yellow">' . __('由于移动端多数浏览器不支持视频背景功能，所以移动端不会显示视频！', 'zib_language') . '</div>',
                'default'                => array(
                    array(
                        'background'    => $imagepath . 'slider-bg.jpg',
                        'image_layer'   => array(
                            array(
                                'image'            => $imagepath . 'slider-layer-1.png',
                                'align'            => 'center',
                                'free_size'        => true,
                                'parallax'         => -100,
                                'parallax_scale'   => 100,
                                'parallax_opacity' => 100,
                            ),
                            array(
                                'image'            => $imagepath . 'slider-layer-2.png',
                                'align'            => 'center',
                                'free_size'        => true,
                                'parallax'         => -50,
                                'parallax_scale'   => 50,
                                'parallax_opacity' => 30,
                            ),
                        ),
                        'link'          => array(
                            'url'    => 'https://www.zibll.com/',
                            'target' => '_blank',
                        ),
                        'desc'          => '',
                        'title'         => '',
                        'text_align'    => 'left-bottom',
                        'text_parallax' => 30,
                        'text_size_m'   => 20,
                        'text_size_pc'  => 30,
                    ),
                ),
                'fields'                 => CFS_Module::add_slider(),
            ),
            array(
                'id'         => 'option',
                'type'       => 'accordion',
                'title'      => __('幻灯片设置', 'zib_language'),
                'default'    => array(
                    'direction'    => 'horizontal',
                    'button'       => true,
                    'pagination'   => true,
                    'effect'       => 'slide',
                    'auto_height'  => false,
                    'pc_height'    => 400,
                    'm_height'     => 240,
                    'spacebetween' => 15,
                    'speed'        => 0,
                    'interval'     => 4,
                ),
                'accordions' => array(
                    array(
                        'title'  => __('幻灯片设置', 'zib_language'),
                        'icon'   => 'fa fa-fw fa-angle-right',
                        'fields' => CFS_Module::slide(),
                    ),
                ),
            ),
        ),
    ));
}
