<?php
/*
 * @Author        : Qinver
 * @Url           : zibll.com
 * @Date          : 2021-08-05 20:25:29
 * @LastEditTime: 2021-09-01 22:17:37
 * @Email         : 2522695764@qq.com
 * @Project       : Zibll子比主题
 * @Description   : 一款极其优雅的Wordpress主题|论坛系统|论坛首页模板
 * @Read me       : 感谢您使用子比主题，主题源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版主题会存在各种未知风险。支持正版，从我做起！
 */


if (zib_bbs_current_user_can('plate_edit')) {
    zib_bbs_page_template('plate_edit');
} else {
    bbs_locate_template_nocan_edit('plate_edit');
}
