<?php
/*
 * @Author: Qinver
 * @Url: zibll.com
 * @Date: 2020-12-21 22:54:02
 * @LastEditTime : 2026-05-05 11:35:37
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!is_super_admin()) {
    wp_die(__('您不能访问此页面', 'zib_language'), __('权限不足', 'zib_language'));
    exit;
}

$this_url  = esc_url(admin_url('admin.php?page=zibpay_charge_card_page'));
$tab       = !empty($_GET['tab']) ? $_GET['tab'] : '';
$action    = !empty($_REQUEST['action']) ? $_REQUEST['action'] : '';
$s         = !empty($_REQUEST['s']) ? esc_sql($_REQUEST['s']) : '';
$type_args = [
    'balance_charge'  => __('余额充值', 'zib_language'),
    'vip_exchange'    => __('会员兑换', 'zib_language'),
    'points_exchange' => __('积分兑换', 'zib_language'),
    'custom'          => __('自定义卡密', 'zib_language'),
];

if ($action) {
    switch ($action) {
        case 'add':
            $add_type  = !empty($_REQUEST['add_type']) ? $_REQUEST['add_type'] : 'auto';
            $pass_type = !empty($_REQUEST['type']) ? $_REQUEST['type'] : '';

            if ($add_type === 'import') {
                //导入卡密
                $import_data     = !empty($_REQUEST['import_data']) ? $_REQUEST['import_data'] : '';
                $import_division = !empty($_REQUEST['import_division']) ? $_REQUEST['import_division'] : ' ';

                if (!$import_data) {
                    zib_admin_page_notice(__('错误！', 'zib_language'), __('请粘贴您需要导入的数据', 'zib_language'), 'error');
                    break;
                }

                $import_data_array = explode("\r\n", $import_data);

                if (!$import_data_array) {
                    zib_admin_page_notice(__('错误！', 'zib_language'), __('导入数据格式异常', 'zib_language'), 'error');
                    break;
                }

                $success_i = 0;
                $error_i   = 0;
                foreach ($import_data_array as $v) {
                    $v         = explode($import_division, $v);
                    $pass_meta = [];
                    $_card     = !empty($v[0]) ? trim($v[0]) : '';
                    $_pass     = !empty($v[1]) ? trim($v[1]) : '';
                    $_other    = !empty($v[3]) ? trim($v[3]) : '';

                    switch ($pass_type) {
                        case 'balance_charge':
                        case 'points_exchange':
                            $v[2] = !empty($v[2]) ? (float) $v[2] : 0;
                            if ($pass_type === 'points_exchange') {
                                $pass_meta = $v[2] ? array('points' => $v[2]) : 0;
                            } else {
                                $pass_meta = $v[2] ? array('price' => $v[2]) : 0;
                            }

                            if (!$pass_meta) {
                                $error_i++;
                                continue 2;
                            }

                            break;

                        case 'vip_exchange':
                            $vip_pass_data = !empty($v[2]) ? wp_parse_args($v[2]) : array();
                            if (!empty($vip_pass_data['level']) && !empty($vip_pass_data['time'])) {
                                $pass_meta = $vip_pass_data;
                            }

                            if (!$pass_meta) {
                                $error_i++;
                                continue 2;
                            }
                            break;

                        case 'custom':
                            $pass_meta   = [];
                            $only_pass_s = !empty($_REQUEST['only_pass_s']) ? true : false;
                            if ($only_pass_s) {
                                //单密码模式
                                $_card       = '';
                                $_pass       = !empty($v[0]) ? trim($v[0]) : '';
                                $_other      = !empty($v[1]) ? trim($v[1]) : '';
                                $custom_name = !empty($v[2]) ? wp_parse_args($v[2]) : [];
                            } else {
                                $_other      = !empty($v[2]) ? trim($v[2]) : '';
                                $custom_name = !empty($v[3]) ? wp_parse_args($v[3]) : [];
                            }

                            if (!empty($custom_name['card_name'])) {
                                $pass_meta['custom_name']['card_name'] = trim($custom_name['card_name']);
                            }
                            if (!empty($custom_name['password_name'])) {
                                $pass_meta['custom_name']['password_name'] = trim($custom_name['password_name']);
                            }

                            break;
                    }

                    if ($_pass) {
                        $success_i++;
                        ZibCardPass::add(array(
                            'card'     => $_card,
                            'password' => $_pass,
                            'type'     => $pass_type,
                            'status'   => '0', //正常
                            'meta'     => $pass_meta,
                            'other'    => $_other,
                        ));
                    } else {
                        $error_i++;
                    }
                }

                if ($success_i) {
                    zib_admin_page_notice(__('导入完成', 'zib_language'), sprintf(__('成功导入%s个卡密%s', 'zib_language'), $success_i, ($error_i ? sprintf(__('，%s个导入失败', 'zib_language'), $error_i) : '')));
                    break;
                } else {
                    zib_admin_page_notice(__('导入失败', 'zib_language'), sprintf(__('%s个导入失败，数据格式错误', 'zib_language'), $error_i), 'error');
                    break;
                }

            } else {
                $auto_num  = !empty($_REQUEST['auto_num']) ? (int) $_REQUEST['auto_num'] : 0;
                $pass_meta = [];

                if (!$auto_num) {
                    zib_admin_page_notice(__('错误！', 'zib_language'), __('请输入需要生成的数量', 'zib_language'), 'error');
                    break;
                }

                switch ($pass_type) {
                    case 'balance_charge':
                    case 'points_exchange':
                        $auto_price = !empty($_REQUEST['auto_price']) ? floatval(round((float) $_REQUEST['auto_price'], 2)) : 0;
                        if (!$auto_price) {
                            zib_admin_page_notice(__('错误！', 'zib_language'), __('请输入卡密的面额', 'zib_language'), 'error');
                            break;
                        }
                        if ($pass_type === 'points_exchange') {
                            $pass_meta = array('points' => $auto_price);
                        }
                        if ($pass_type === 'balance_charge') {
                            $pass_meta = array('price' => $auto_price);
                        }
                        break;
                    case 'vip_exchange':
                        if (empty($_REQUEST['vip_exchange']['time'])) {
                            zib_admin_page_notice(__('错误！', 'zib_language'), __('请填写兑换会员参数', 'zib_language'), 'error');
                            break;
                        }
                        $pass_meta = $_REQUEST['vip_exchange'];
                        break;

                }

                //生成充值卡
                $rand_number   = 20;
                $rand_password = 35;
                if (!empty($_REQUEST['auto_top_s'])) {
                    $rand_number   = isset($_REQUEST['auto_rand_number_limit']) ? (int) $_REQUEST['auto_rand_number_limit'] : 20;
                    $rand_password = !empty($_REQUEST['auto_rand_password_limit']) ? (int) $_REQUEST['auto_rand_password_limit'] : 35;
                }

                $remarks     = !empty($_REQUEST['auto_remarks']) ? $_REQUEST['auto_remarks'] : '';
                $custom_name = !empty($_REQUEST['custom_name']) ? $_REQUEST['custom_name'] : [];
                if (!empty($custom_name['card_name'])) {
                    $pass_meta['custom_name']['card_name'] = trim($custom_name['card_name']);
                }
                if (!empty($custom_name['password_name'])) {
                    $pass_meta['custom_name']['password_name'] = trim($custom_name['password_name']);
                }

                zibpay_generate_pass_card($pass_type, $auto_num, $pass_meta, $rand_number, $rand_password, $remarks);

                zib_admin_page_notice(__('完成！', 'zib_language'), sprintf(__('已自动生成%s个卡密', 'zib_language'), $auto_num));
                break;
            }

            zib_admin_page_notice(__('错误！', 'zib_language'), __('参数传入错误', 'zib_language'), 'error');

            break;

        case 'delete':
            $delete_ids = !empty($_REQUEST['action_id']) ? $_REQUEST['action_id'] : 0;
            if (!$delete_ids) {
                zib_admin_page_notice(__('错误！', 'zib_language'), __('未选择需要删除的内容', 'zib_language'), 'error');
                break;
            }
            $delete_i = ZibCardPass::delete(array(
                'id'   => $delete_ids,
                'type' => array_keys($type_args),
            ));

            zib_admin_page_notice(__('删除完成', 'zib_language'), sprintf(__('已删除%s个卡密', 'zib_language'), $delete_i));
            break;
    }
}

function zib_admin_page_notice($title = '', $msg = '', $type = 'success')
{
    $html = '';
    $html .= $title ? '<h3>' . $title . '</h3>' : '';
    $html .= $msg ? '<p>' . $msg . '</p>' : '';

    if ($html) {
        echo '<div class="notice notice-' . $type . '">' . $html . '</div>';
    }
}

$page_title = __('卡密管理', 'zib_language');
$head_but   = '<a href="' . add_query_arg('tab', 'add', $this_url) . '" class="page-title-action">' . esc_html__('添加卡密', 'zib_language') . '</a>';
$sub_but    = array();

//准备查询参数
$msg_type    = !empty($_REQUEST['msg_type']) ? $_REQUEST['msg_type'] : 0;
$user_id     = !empty($_REQUEST['user_id']) ? $_REQUEST['user_id'] : 0;
$orderby     = !empty($_REQUEST['orderby']) ? $_REQUEST['orderby'] : 'modified_time';
$paged       = !empty($_REQUEST['paged']) ? $_REQUEST['paged'] : 1;
$ice_perpage = !empty($_REQUEST['ice_perpage']) ? $_REQUEST['ice_perpage'] : 30;
$desc        = !empty($_REQUEST['desc']) ? $_REQUEST['desc'] : 'DESC';
$offset      = $ice_perpage * ($paged - 1);

$count_all = 0;
$db_data   = false;
$csf_args  = false;
$table     = false;
$pagenavi  = false;
$search    = false;
$page_html = false;

switch ($tab) {

    case 'add':
        $page_title = __('添加卡密', 'zib_language');
        $head_but   = '<a href="' . $this_url . '" class="page-title-action">' . esc_html__('返回列表', 'zib_language') . '</a>';

        $csf_fields = array();

        $csf_fields[] = array(
            'content' => '<p><b>' . esc_html__('在此添加卡密', 'zib_language') . '</b></p>
            <li>' . esc_html__('如果您已经准备好了卡密资料，请选择导入的方式添加', 'zib_language') . '</li>
            <li>' . esc_html__('您也可以采用系统生成的方式，自动批量添加卡密', 'zib_language') . '</li>',
            'style'   => 'warning',
            'type'    => 'submessage',
        );

        $csf_fields[] = array(
            'id'      => 'type',
            'type'    => 'button_set',
            'title'   => __('卡密类型', 'zib_language'),
            'inline'  => true,
            'options' => array(
                'balance_charge'  => __('余额充值', 'zib_language'),
                'vip_exchange'    => __('会员兑换', 'zib_language'),
                'points_exchange' => __('积分兑换', 'zib_language'),
                'custom'          => __('自定义卡密', 'zib_language'),
            ),
            'default' => 'balance_charge',
        );

        $csf_fields[] = array(
            'id'      => 'add_type',
            'type'    => 'button_set',
            'title'   => __('添加方式', 'zib_language'),
            'inline'  => true,
            'options' => array(
                'auto'   => __('系统自动生成', 'zib_language'),
                'import' => __('导入卡密', 'zib_language'), //导入
            ),
            'default' => 'auto',
        );

        $csf_fields[] = array(
            'dependency' => array('add_type', '==', 'auto'),
            'title'      => __('生成数量', 'zib_language'),
            'id'         => 'auto_num',
            'default'    => 20,
            'min'        => 1,
            'max'        => 1000,
            'step'       => 10,
            'unit'       => __('张', 'zib_language'),
            'desc'       => __('需要生成多少张卡密（单次生成数量太多可能会对服务器性能造成影响）', 'zib_language'),
            'type'       => 'spinner',
        );

        $csf_fields[] = array(
            'dependency' => array('add_type', '==', 'auto'),
            'title'      => __('标识', 'zib_language'),
            'desc'       => __('对生成的卡密做标记标识，方便后期查找管理', 'zib_language') . '<br>' . sprintf(__('注意：标识中不能有%1$s字符，系统已占用', 'zib_language'), '<code>shipped</code>'),
            'id'         => 'auto_remarks',
            'default'    => 'cardpass_' . current_time('YmdHis'),
            'type'       => 'text',
        );

        $csf_fields[] = array(
            'dependency' => array('add_type|type', '==|any', 'auto|balance_charge,points_exchange'),
            'id'         => 'auto_price',
            'title'      => __('面额', 'zib_language'),
            'desc'       => __('单张卡密的面额', 'zib_language'),
            'default'    => 0,
            'type'       => 'number',
            'unit'       => '',
        );

        $csf_fields[] = array(
            'dependency' => array('add_type|type', '==|==', 'auto|vip_exchange'),
            'title'      => __('兑换会员', 'zib_language'),
            'id'         => 'vip_exchange',
            'type'       => 'fieldset',
            'fields'     => array(
                array(
                    'title'   => __('会员等级', 'zib_language'),
                    'id'      => 'level',
                    'type'    => 'radio',
                    'default' => '1',
                    'inline'  => true,
                    'options' => array(
                        '1' => _pz('pay_user_vip_1_name'),
                        '2' => _pz('pay_user_vip_2_name'),
                    ),
                ),
                array(
                    'title'    => ' ',
                    'subtitle' => __('兑换会员时长', 'zib_language'),
                    'desc'     => __('填', 'zib_language') . '<code>Permanent</code>' . __('为永久', 'zib_language'),
                    'id'       => 'time',
                    'default'  => '',
                    'type'     => 'text',
                ),
                array(
                    'dependency' => array('time', '!=', 'Permanent'),
                    'title'      => ' ',
                    'subtitle'   => __('时长单位', 'zib_language'),
                    'id'         => 'unit',
                    'type'       => 'radio',
                    'default'    => 'month',
                    'options'    => array(
                        'day'   => __('天', 'zib_language'),
                        'month' => __('个月', 'zib_language'),
                    ),
                ),
            ),
        );

        $csf_fields[] = array(
            'dependency' => array('add_type|type', '==|==|==', 'auto|custom'),
            'title'      => __('自定义显示名称', 'zib_language'),
            'id'         => 'custom_name',
            'type'       => 'fieldset',
            'fields'     => array(
                array(
                    'title'   => __('卡号显示名称', 'zib_language'),
                    'id'      => 'card_name',
                    'default' => '',
                    'type'    => 'text',
                ),
                array(
                    'title'   => __('卡密显示名称', 'zib_language'),
                    'class'   => 'compact',
                    'id'      => 'password_name',
                    'default' => '',
                    'type'    => 'text',
                ),
            ),
        );

        $csf_fields[] = array(
            'dependency' => array('add_type', '==', 'auto'),
            'title'      => __('高级选项', 'zib_language'),
            'id'         => 'auto_top_s',
            'default'    => false,
            'type'       => 'switcher',
        );

        $csf_fields[] = array(
            'dependency' => array('add_type|auto_top_s', '==|!=', 'auto|'),
            'title'      => __('自定义卡号位数', 'zib_language'),
            'id'         => 'auto_rand_number_limit',
            'default'    => 20,
            'min'        => 1,
            'max'        => 50,
            'step'       => 5,
            'unit'       => __('位数', 'zib_language'),
            'type'       => 'spinner',
        );

        $csf_fields[] = array(
            'dependency' => array('add_type|auto_top_s', '==|!=', 'auto|'),
            'title'      => __('自定义密码位数', 'zib_language'),
            'class'      => 'compact',
            'id'         => 'auto_rand_password_limit',
            'default'    => 35,
            'min'        => 1,
            'max'        => 50,
            'step'       => 5,
            'unit'       => __('位数', 'zib_language'),
            'desc'       => __('自定义自动生成的长度（不能太短，太短可能会出现重复）如果启用了单密码模式，可以将卡号位数设置为0', 'zib_language'),
            'type'       => 'spinner',
        );

        //导入卡密
        $csf_fields[] = array(
            'dependency' => array('add_type|type', '!=|any', 'auto|balance_charge,points_exchange'),
            'content'    => '<p><b>' . esc_html__('导入卡密', 'zib_language') . '</b></p>
            <li>' . esc_html__('一行一个卡密，单行格式为：', 'zib_language') . '<code>' . esc_html__('卡号 密码 面额 标识', 'zib_language') . '</code></li>
            <li>' . esc_html__('卡号、密码、面额、标识默认使用空格分割，您可以在下方自定义分割符号，与您的数据对应即可', 'zib_language') . '</li>
            <li>' . esc_html__('单次导入数量太多可能会对服务器性能造成影响', 'zib_language') . '</li><li>' . esc_html__('如果使用的是单密码模式，卡号部分随便填什么都行，但不能留空', 'zib_language') . '</li>
            <p><b>' . esc_html__('数据示例', 'zib_language') . '</b></p>
            <div>4849977843617 3w20V4Qe7dRhAIoPYum6KSA 50 ' . esc_html__('50元余额', 'zib_language') . '</div>
            <div>6484027668705 SkdJZ5vWcpqPxrbs3pqPcpq 100 ' . esc_html__('100元余额', 'zib_language') . '</div>',
            'style'      => 'warning',
            'type'       => 'submessage',
        );
        $csf_fields[] = array(
            'dependency' => array('add_type|type', '!=|==', 'auto|vip_exchange'),
            'content'    => '<p><b>' . esc_html__('导入会员兑换卡密', 'zib_language') . '</b></p>
            <li>' . esc_html__('一行一个卡密，单行格式为：', 'zib_language') . '<code>' . esc_html__('卡号 密码 会员参数 标识', 'zib_language') . '</code></li>
            <li>' . esc_html__('卡号、密码、面额、标识默认使用空格分割，您可以在下方自定义分割符号，与您的数据对应即可', 'zib_language') . '</li>
            <li>' . esc_html__('会员参数格式为：', 'zib_language') . '<code>level=1&time=5&unit=day</code></li>
            <li>' . esc_html__('参数说明：level为等级，只能为1或2。time为时长，填Permanent或数字。unit为时长单位，只能填day(天)或者month(月)', 'zib_language') . '</li>
            <li>' . esc_html__('单次导入数量太多可能会对服务器性能造成影响', 'zib_language') . '</li><li>' . esc_html__('如果使用的是单密码模式，卡号部分随便填什么都行，但不能留空', 'zib_language') . '</li>
            <p><b>' . esc_html__('数据示例', 'zib_language') . '</b></p>
            <div>4849977843617 3w20V4Qe7dRhAIoPYum6KSA level=1&time=5&unit=day ' . esc_html__('5天一级会员', 'zib_language') . '</div>
            <div>6484027668705 SkdJZ5vWcpqPxrbs3pqPcpq level=2&time=Permanent ' . esc_html__('永久2级会员', 'zib_language') . '</div>
            ',
            'style'      => 'warning',
            'type'       => 'submessage',
        );
        $csf_fields[] = array(
            'dependency' => array('add_type|type', '==|==', 'import|custom'),
            'title'      => __('单密码模式', 'zib_language'),
            'id'         => 'only_pass_s',
            'default'    => false,
            'type'       => 'switcher',
        );

        $csf_fields[] = array(
            'dependency' => array('add_type|type|only_pass_s', '!=|==|==', 'auto|custom|'),
            'content'    => '<p><b>' . esc_html__('自定义卡密导入', 'zib_language') . '</b></p>
            <li>' . esc_html__('一行一个卡密，单行格式为：', 'zib_language') . '<code>' . esc_html__('卡号 密码 标识 自定义参数', 'zib_language') . '</code></li>
            <li>' . esc_html__('默认使用空格分割，您可以在下方自定义分割符号，与您的数据对应即可', 'zib_language') . '</li>
            <li>' . esc_html__('自定义参数格式为：', 'zib_language') . '<code>card_name=授权号&password_name=授权密码</code>,' . esc_html__('card_name为卡号的显示名称，password_name为卡密的显示名称，可以留空', 'zib_language') . '</li>
            <li>' . esc_html__('单次导入数量太多可能会对服务器性能造成影响', 'zib_language') . '</li>
            <p><b>' . esc_html__('数据示例', 'zib_language') . '</b></p>
            <div>4849977843617 3w20V4Qe7dRhAIoPYum6KSA ' . esc_html__('平台卡密01', 'zib_language') . ' card_name=' . esc_html__('授权号', 'zib_language') . '&password_name=' . esc_html__('授权码', 'zib_language') . '</div>
            <div>6484027668705 SkdJZ5vWcpqPxrbs3pqPcpq ' . esc_html__('平台卡密01', 'zib_language') . ' card_name=' . esc_html__('授权号', 'zib_language') . '&password_name=' . esc_html__('授权码', 'zib_language') . '</div>
            <div>111111@qq.com 11assssddsds ' . esc_html__('某某账号', 'zib_language') . ' card_name=' . esc_html__('账号', 'zib_language') . '&password_name=' . esc_html__('密码', 'zib_language') . '</div>',
            'style'      => 'warning',
            'type'       => 'submessage',
        );
        $csf_fields[] = array(
            'dependency' => array('add_type|type|only_pass_s', '!=|==|!=', 'auto|custom|'),
            'content'    => '<p><b>' . esc_html__('自定义卡密导入（单密码模式）', 'zib_language') . '</b></p>
            <li>' . esc_html__('一行一个卡密，单行格式为：', 'zib_language') . '<code>' . esc_html__('密码 标识 自定义参数', 'zib_language') . '</code></li>
            <li>' . esc_html__('默认使用空格分割，您可以在下方自定义分割符号，与您的数据对应即可', 'zib_language') . '</li>
            <li>' . esc_html__('单次导入数量太多可能会对服务器性能造成影响', 'zib_language') . '</li>
            <li>' . esc_html__('自定义参数格式为：', 'zib_language') . '<code>password_name=授权密码</code>，' . esc_html__('password_name为卡密的显示名称，可以留空', 'zib_language') . '</li>
            <p><b>' . esc_html__('数据示例', 'zib_language') . '</b></p>
            <div>3w20V4Qe7dRhAIoPYum6KSA ' . esc_html__('平台卡密01', 'zib_language') . ' password_name=' . esc_html__('授权码', 'zib_language') . '</div>
            <div>SkdJZ5vWcpqPxrbs3pqPcpq ' . esc_html__('平台卡密01', 'zib_language') . ' password_name=' . esc_html__('授权码', 'zib_language') . '</div>',
            'style'      => 'warning',
            'type'       => 'submessage',
        );
        $csf_fields[] = array(
            'dependency' => array('add_type', '==', 'import'),
            'title'      => __('卡密数据', 'zib_language'),
            'id'         => 'import_data',
            'default'    => '',
            'attributes' => array(
                'rows'  => 10,
                'style' => 'resize: both;max-width: none;',
            ),
            'sanitize'   => false,
            'type'       => 'textarea',
        );
        $csf_fields[] = array(
            'dependency' => array('add_type', '==', 'import'),
            'id'         => 'import_division', //分割
            'title'      => __('自定义分隔符号', 'zib_language'),
            'subtitle'   => '',
            'class'      => 'mini-input',
            'default'    => ' ',
            'desc'       => __('卡号和密码之间分割符号（默认为空格分割）', 'zib_language'),
            'type'       => 'text',
        );
        $csf_fields[] = array(
            'title'   => ' ',
            'type'    => 'content',
            'content' => '<button type="submit" class="but jb-blue">' . esc_html__('确认提交', 'zib_language') . '</button>',
        );

        $csf_args = array(
            'class'  => 'csf-profile-options',
            'method' => 'post',
            'value'  => array(),
            'hidden' => array(
                array(
                    'name'  => 'action',
                    'value' => 'add',
                ),
            ),
            'fields' => $csf_fields,
        );

        break;

    case 'export':

        $page_title = __('导出卡密', 'zib_language');
        $head_but   = '<a href="' . $this_url . '" class="page-title-action">' . esc_html__('返回列表', 'zib_language') . '</a>';

        $csf_fields   = array();
        $csf_fields[] = array(
            'id'      => 'type',
            'type'    => 'button_set',
            'title'   => __('卡密类型', 'zib_language'),
            'inline'  => true,
            'options' => $type_args,
            'default' => 'balance_charge',
        );
        $csf_fields[] = array(
            'dependency' => array('type', '!=', 'custom'),
            'id'         => 'status',
            'type'       => 'radio',
            'title'      => __('选择状态', 'zib_language'),
            'inline'     => true,
            'options'    => array(
                'all'  => __('全部', 'zib_language'),
                '0'    => __('未使用', 'zib_language'), //导入
                'used' => __('已使用', 'zib_language'), //导入
            ),
            'default'    => 'all',
        );
        $csf_fields[] = array(
            'id'      => 'export_format',
            'type'    => 'radio',
            'title'   => __('导出格式', 'zib_language'),
            'inline'  => true,
            'options' => array(
                'text' => __('文本文档', 'zib_language'),
                'xls'  => __('Excel表格', 'zib_language'), //导入
            ),
            'default' => 'xls',
        );

        $csf_fields[] = array(
            'dependency' => array('export_format', '==', 'text'),
            'id'         => 'text_division', //分割
            'title'      => ' ',
            'subtitle'   => __('分隔符号', 'zib_language'),
            'class'      => 'mini-input',
            'default'    => ' ',
            'desc'       => __('卡号和密码之间分割符号（默认为空格分割）', 'zib_language'),
            'type'       => 'text',
        );

        $csf_fields[] = array(
            'title'   => ' ',
            'type'    => 'content',
            'content' => '<button type="submit" class="but jb-blue">' . esc_html__('确认提交', 'zib_language') . '</button>',
        );

        $csf_args = array(
            'class'  => 'csf-profile-options',
            'method' => 'post',
            'action' => admin_url('admin-ajax.php'),
            'value'  => array(),
            'hidden' => array(
                array(
                    'name'  => 'action',
                    'value' => 'card_pass_export',
                ),
            ),
            'fields' => $csf_fields,
        );

        break;

    default:
        //默认页面，展示卡密列表
        $pagenavi  = true;
        $sub_but[] = array(
            'name' => __('全部', 'zib_language'),
            'href' => $this_url,
        );

        $head_but .= '<a href="' . add_query_arg(['tab' => 'export'], $this_url) . '" class="page-title-action">' . esc_html__('导出卡密', 'zib_language') . '</a>';

        if ($s) {
            $head_but .= '<div><div class="update-nag" style="margin: 10px 0 0;">' . sprintf(esc_html__('搜索 “%s” 的内容', 'zib_language'), esc_html($s)) . ' </div></div>';
        } else {
            $sub_but[] = array(
                'name' => __('未使用', 'zib_language'),
                'href' => add_query_arg('status', '0', $this_url),
            );

            $sub_but[] = array(
                'name' => __('已使用', 'zib_language'),
                'href' => add_query_arg('status', 'used', $this_url),
            );

            foreach ($type_args as $_k => $_v) {
                $sub_but[] = array(
                    'name' => $_v,
                    'href' => add_query_arg('type', $_k, $this_url),
                );
            }
        }

        $where = array(
            'type' => array_keys($type_args),
        );

        if (isset($_GET['type'])) {
            $where['type'] = $_GET['type'];
        }

        if (isset($_GET['status'])) {
            $where['status'] = $_GET['status'];
        }
        if (isset($_GET['other'])) {
            $where['other'] = $_GET['other'];
        }

        $db = ZibDB::name(ZibCardPass::$table_name);
        $db->where($where)->order($orderby, $desc)->page($paged, $ice_perpage);
        if ($s) {
            $db->whereLike(['card', 'password', 'other', 'meta'], $s);
        }

        $db_data   = $db->select()->result();
        $count_all = $db->count();

        $table = '<thead><tr><td style="color: #ff4a4a;text-align: center;">' . esc_html__('未找到对应内容，或暂无内容', 'zib_language') . '</td></tr></thead>';
        if ($db_data) {
            $table    = '';
            $theads[] = array('width' => '6%', 'orderby' => 'card', 'name' => __('卡号', 'zib_language'));
            $theads[] = array('width' => '10%', 'orderby' => 'password', 'name' => __('密码', 'zib_language'));
            $theads[] = array('width' => '5%', 'orderby' => 'type', 'name' => __('类型', 'zib_language'));
            $theads[] = array('width' => '5%', 'orderby' => 'create_time', 'name' => __('创建时间', 'zib_language'));
            $theads[] = array('width' => '5%', 'orderby' => 'modified_time', 'name' => __('更新时间', 'zib_language'));
            $theads[] = array('width' => '5%', 'orderby' => 'status', 'name' => __('状态', 'zib_language'));
            $theads[] = array('width' => '8%', 'orderby' => 'other', 'name' => __('标识', 'zib_language'));

            $thead_th = '<td id="cb" class="manage-column column-cb check-column" style="width: 2%;"><label class="screen-reader-text" for="cb-select-all-1">' . esc_html__('全选', 'zib_language') . '</label><input id="cb-select-all-1" type="checkbox"></td>';
            foreach ($theads as $thead) {
                $orderby = '';
                if ($thead['orderby']) {
                    $orderby_url = add_query_arg('orderby', $thead['orderby']);
                    $orderby .= '<a title="' . esc_attr__('降序', 'zib_language') . '" href="' . add_query_arg('desc', 'ASC', $orderby_url) . '"><span class="dashicons dashicons-arrow-up"></span></a>';
                    $orderby .= '<a title="' . esc_attr__('升序', 'zib_language') . '" href="' . add_query_arg('desc', 'DESC', $orderby_url) . '"><span class="dashicons dashicons-arrow-down"></span></a>';
                    $orderby = '<span class="orderby-but">' . $orderby . '</span>';
                }
                $thead_th .= '<th class="" width="' . $thead['width'] . '">' . $thead['name'] . $orderby . '</th>';
            }
            $table .= '<thead><tr>' . $thead_th . '</tr></thead>';

            $tbody = '';
            foreach ($db_data as $msg) {
                $meta        = maybe_unserialize($msg->meta);
                $status_html = '';
                if ($msg->type === 'custom') {
                    $type_html = '<a style="color:#a42ade" href="' . add_query_arg('type', 'custom', $this_url) . '">' . esc_html__('自定义卡密', 'zib_language') . '</a>';

                } else {
                    $status_html = '<span style="color: #3d7ffd;">' . esc_html__('未使用', 'zib_language') . '</span>';
                    if ($msg->status === 'used') {
                        $status_html = '<span style="color: #f93b3b;">' . esc_html__('已使用', 'zib_language') . '</span>';
                        if ($msg->order_num) {
                            $order_link_url = zibpay_get_admin_shop_order_url('search=' . $msg->order_num); //前缀
                            $status_html .= '<a style="color: #ff6215;" target="_blank" href="' . $order_link_url . '"> [' . esc_html__('查看', 'zib_language') . ']</a>';
                        }
                    }
                }

                $other_a = '';
                if ($msg->other) {
                    $other_a = '<a href="' . add_query_arg('other', $msg->other, $this_url) . '">' . $msg->other . '</a>';
                }

                if ($msg->type === 'vip_exchange') {
                    $type_html          = '<a style="color:#975106" href="' . add_query_arg('type', 'vip_exchange', $this_url) . '">' . esc_html__('会员兑换', 'zib_language') . '</a>';
                    $exchange_card_data = zibpay_get_vip_exchange_card_data($msg);
                    if ($exchange_card_data['time'] === 'Permanent') {
                        $exchange_card_time = __('永久', 'zib_language');
                    } else {
                        $exchange_card_time = (int) $exchange_card_data['time'] . ($exchange_card_data['unit_show']);
                    }

                    $type_html .= '<br>' . _pz('pay_user_vip_' . $exchange_card_data['level'] . '_name') . '：' . $exchange_card_time;

                } elseif ($msg->type === 'points_exchange') {
                    $type_html = '<a style="color:#289d0f" href="' . add_query_arg('type', 'points_exchange', $this_url) . '">' . esc_html__('积分兑换', 'zib_language') . '</a>';
                    $type_html .= '<br>' . esc_html__('积分：', 'zib_language') . zibpay_get_pass_exchange_points($msg);
                } elseif ($msg->type === 'balance_charge') {
                    $type_html = '<a style="color:#0c76e6" href="' . add_query_arg('type', 'balance_charge', $this_url) . '">' . esc_html__('余额充值', 'zib_language') . '</a>';
                    $type_html .= '<br>' . esc_html__('金额：', 'zib_language') . zibpay_get_recharge_card_price($msg);
                }

                //正则匹配“自定义-005_shipped_848”，shipped_后后面的数字也是订单ID
                if (!empty($meta['shipped_order_id']) || preg_match('/shipped_(\d+)/', $msg->other, $matches)) {

                    $shipped_order_id = !empty($meta['shipped_order_id']) ? $meta['shipped_order_id'] : (int) $matches[1];
                    $status_html .= '<br>' . esc_html__('已售', 'zib_language') . '<a style="color: #ca7f5a;" target="_blank" href="' . zibpay_get_admin_shop_url('shipping', 'id=' . $shipped_order_id) . '"> [' . esc_html__('查看', 'zib_language') . ']</a>';
                }

                //自定义显示名称
                $card_name     = '';
                $password_name = '';
                if (!empty($meta['custom_name'])) {
                    $custom_name = $meta['custom_name'];
                    if (!empty($custom_name['card_name'])) {
                        $card_name = $custom_name['card_name'];
                    }
                    if (!empty($custom_name['password_name'])) {
                        $password_name = $custom_name['password_name'];
                    }
                }

                $tbody .= '<tr>';
                $tbody .= '<th scope="row" class="check-column"><label class="screen-reader-text" for="cb-select-232">' . esc_html__('选择', 'zib_language') . '</label>
                <input id="cb-select-232" type="checkbox" name="action_id[]" value="' . $msg->id . '">
                    </th>';
                $tbody .= "<td><span data-clipboard-text='$msg->card' data-clipboard-tag=\"" . esc_attr($card_name ?: __('卡号', 'zib_language')) . "\">$card_name $msg->card</span></td>";
                $tbody .= "<td><span data-clipboard-text='$msg->password' data-clipboard-tag=\"" . esc_attr($password_name ?: __('密码', 'zib_language')) . "\">$password_name $msg->password</span></td>";
                $tbody .= "<td>$type_html</td>";
                $tbody .= "<td>$msg->create_time</td>";
                $tbody .= "<td>$msg->modified_time</td>";
                $tbody .= "<td>$status_html</td>";
                $tbody .= "<td>$other_a</td>";
                $tbody .= '</tr>';
            }
            $table .= '<tbody>' . $tbody . '</tbody>';
        }

        $search = '<form class="form-inline form-order" method="post">
                    <div class="form-group" style="float: right;">
                        <input type="text" class="form-control" name="s" placeholder="' . esc_attr__('搜索卡密', 'zib_language') . '">
                        <button type="submit" class="button">' . esc_html__('提交', 'zib_language') . '</button>
                    </div>
                </form>';

        break;
}

?>


<div class="wrap">
    <style>
        .orderby-but {
            position: relative;
        }

        .orderby-but>a {
            opacity: .4;
            position: absolute;
            transform: translateY(-3px);
            transition: .3s;
        }

        .orderby-but>a+a {
            transform: translateY(6px);
        }

        .orderby-but:hover a {
            opacity: .6;
        }

        .orderby-but>a:hover {
            opacity: 1;
        }
    </style>
    <h1 class="wp-heading-inline"><?php echo $page_title; ?></h1>
    <?php echo $head_but; ?>
    <?php
$but_html = '';
if ($sub_but) {
    foreach ($sub_but as $but) {
        $but_html .= '<li><a href="' . $but['href'] . '">' . $but['name'] . '</a></li> | ';
    }
}

echo '<div class="order-header"><ul class="subsubsub">' . substr($but_html, 0, -2) . '</ul>' . $search . '</div>';

if ($table) {

    echo '<div class="clear"></div>';
    echo '<form class="" method="post">';
    echo '<div class="bulkactions" style="margin: 10px 0;">
			<label for="bulk-action-selector-top" class="screen-reader-text">' . esc_html__('选择批量操作', 'zib_language') . '</label><select name="action" id="bulk-action-selector-top">
                <option value="-1">' . esc_html__('批量操作', 'zib_language') . '</option>
                    <option value="delete">' . esc_html__('删除', 'zib_language') . '</option>
                </select>
                <input type="submit" class="button action" value="' . esc_attr__('应用', 'zib_language') . '">
		</div>';

    echo '<div style="overflow-y: auto;width: 100%;">';
    echo '<table class="widefat fixed striped posts table table-bordered" style="min-width: 1000px;">';
    echo $table;
    echo '</table>';
    echo '</div>';
    echo '</form>';
    echo '<div class="clear"></div>';

} elseif ($csf_args) {
    ZCSF::instance('add_msg', $csf_args);
}
if ($page_html) {
    echo $page_html;
}
if ($pagenavi) {
    zibpay_admin_pagenavi($count_all, $ice_perpage);
}

?>


</div>